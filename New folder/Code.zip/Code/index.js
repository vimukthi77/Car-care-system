var express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

var app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

let students = [{ "id": 1, "name": "Nimal", "address": "Malabe" }];
let student = { "id": 53, "name": "Saman", "address": "Colombo 3" };
students.push(student);

app.get('/', function (req, res) {
    res.send('Hello World!');
});

app.get('/students', function (req, res) {
    res.json(students);
});

app.get('/student/:id', function (req, res) {
    let id = parseInt(req.params.id);
    let tempStu = students.filter((x) => x.id == id)[0];

    if (tempStu) {
        res.json(tempStu);
    } else {
        res.sendStatus(404);
    }
});

app.post("/student", (req, res) => {
    const newstudent = req.body;
    students.push(newstudent);
    res.send('Student is added to the list');
});

app.put("/student/:id", (req, res) => {
    let sid = parseInt(req.params.id);
    let stu = req.body;
    let tempStu = students.filter((x) => x.id === sid)[0];

    if (tempStu) {
        tempStu.name = stu.name;
        tempStu.Address = stu.Address;
        res.sendStatus(200);
    } else {
        res.sendStatus(404);
    }
});

app.delete("/student/:id", (req, res) => {
    let studentId = req.params.id;
    let currentStudent = students.filter((x) => x.id == studentId)[0];

    if (currentStudent) {
        students = students.filter((x) => x.id != studentId);
        res.statusMessage = "Student deleted successfully.";
        res.sendStatus(200);
    } else {
        res.statusMessage = "Student does not exist";
        res.sendStatus(404);
    }
});

app.listen(3000, function () {
    console.log('Example app listening on port 3000!');
});