# java-curve-line-chart
This project custom using java swing graphics2d and animation

![2022-12-02_234505](https://user-images.githubusercontent.com/58245926/205349149-fc12666e-6bd3-4b1a-aae1-f409bfd3f61b.png)

![2022-12-02_234425](https://user-images.githubusercontent.com/58245926/205349155-530ea7e8-8e16-4429-bd90-948fa0e57358.png)

![curve line chart](https://user-images.githubusercontent.com/58245926/205355303-7201cd86-4f91-4282-a6ff-1db0b8135140.gif)
