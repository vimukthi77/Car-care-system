package com.raven.event;

public interface EventMenu {

    public void selected(int index);
}
